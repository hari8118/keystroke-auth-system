document.addEventListener('DOMContentLoaded', () => {
    // Tabs
    const tabEnroll = document.getElementById('tabEnroll');
    const tabAuth = document.getElementById('tabAuth');
    const viewEnroll = document.getElementById('viewEnroll');
    const viewAuth = document.getElementById('viewAuth');

    // Enroll elements
    const enrollUsername = document.getElementById('enrollUsername');
    const enrollPassword = document.getElementById('enrollPassword');
    const startEnrollBtn = document.getElementById('startEnrollBtn');
    const enrollBox = document.getElementById('enrollBox');
    const enrollInstruction = document.getElementById('enrollInstruction');
    const enrollTypingInput = document.getElementById('enrollTypingInput');

    // Auth elements
    const authSelectUser = document.getElementById('authSelectUser');
    const authExpectedPassword = document.getElementById('authExpectedPassword');
    const authTypingInput = document.getElementById('authTypingInput');
    const authTypingStatus = document.getElementById('authTypingStatus');
    const clearAuthBtn = document.getElementById('clearAuthBtn');

    const logContent = document.getElementById('logContent');

    // State
    let usersMap = {}; // { username: password }
    let enrollAttempts = []; // stores 5 arrays of key events
    let enrollKeyEvents = [];  // key events for current enrollment attempt
    let authKeyEvents = [];    // key events for current auth attempt
    let isProcessing = false;

    // --- Utility: Logging ---
    function appendLog(message, type = 'info') {
        const entry = document.createElement('div');
        entry.className = `log-entry ${type}`;
        const timestamp = new Date().toLocaleTimeString('en-US', { hour12: false, fractionalSecondDigits: 3 });
        entry.textContent = `[${timestamp}] ${message}`;
        logContent.appendChild(entry);
        logContent.scrollTop = logContent.scrollHeight;
    }

    // --- Tab Switching ---
    tabEnroll.addEventListener('click', () => {
        tabEnroll.classList.add('active');
        tabAuth.classList.remove('active');
        viewEnroll.classList.remove('hidden');
        viewAuth.classList.add('hidden');
    });

    tabAuth.addEventListener('click', () => {
        tabAuth.classList.add('active');
        tabEnroll.classList.remove('active');
        viewAuth.classList.remove('hidden');
        viewEnroll.classList.add('hidden');
        loadUsers();
    });

    // --- Key capture utility ---
    function captureKey(e, eventsArray) {
        // Filter out modifier and control keys entirely
        const IGNORE = ['Shift', 'Control', 'Alt', 'Meta', 'Backspace', 'Tab',
                        'CapsLock', 'Escape', 'Enter', 'Dead', 'Unidentified',
                        'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight',
                        'Home', 'End', 'PageUp', 'PageDown', 'Insert', 'Delete',
                        'F1','F2','F3','F4','F5','F6','F7','F8','F9','F10','F11','F12'];
        if (IGNORE.includes(e.key)) return false;
        if (isProcessing) { e.preventDefault(); return false; }
        eventsArray.push({
            key: e.key,
            code: e.code,   // physical key — stable regardless of Shift state
            type: e.type,
            time: performance.now()
        });
        return true;
    }

    // ==========================================
    // PHASE 1: ENROLLMENT LOGIC
    // ==========================================
    startEnrollBtn.addEventListener('click', () => {
        const user = enrollUsername.value.trim();
        const pwd = enrollPassword.value.trim();
        
        if (user.length < 2) return appendLog("Username too short.", "error");
        if (pwd.length < 4) return appendLog("Password must be at least 4 chars.", "error");

        enrollUsername.disabled = true;
        enrollPassword.disabled = true;
        startEnrollBtn.classList.add('hidden');
        enrollBox.classList.remove('hidden');
        
        enrollAttempts = [];
        enrollKeyEvents = [];
        enrollInstruction.textContent = `Type your password (Attempt 1 of 5):`;
        enrollTypingInput.value = '';
        enrollTypingInput.focus();
        appendLog(`Started enrollment for ${user} with password "${pwd}"`, "info");
    });

    enrollTypingInput.addEventListener('keydown', (e) => captureKey(e, enrollKeyEvents));
    enrollTypingInput.addEventListener('keyup', (e) => {
        if (captureKey(e, enrollKeyEvents)) {
            checkEnrollCompletion();
        }
    });

    function checkEnrollCompletion() {
        const pwd = enrollPassword.value.trim();
        setTimeout(() => {
            const val = enrollTypingInput.value;
            if (val.length >= pwd.length) {
                if (val === pwd) {
                    enrollAttempts.push([...enrollKeyEvents]);
                    const attemptNum = enrollAttempts.length;
                    appendLog(`Attempt ${attemptNum}/5 captured.`, "success");
                    if (attemptNum >= 5) {
                        submitEnrollment();
                    } else {
                        enrollKeyEvents = [];
                        enrollTypingInput.value = '';
                        enrollInstruction.textContent = `Type your password (Attempt ${attemptNum + 1} of 5):`;
                    }
                } else {
                    appendLog(`Mismatch. Expected '${pwd}'. Try again.`, "error");
                    enrollKeyEvents = [];
                    enrollTypingInput.value = '';
                }
            }
        }, 10);
    }

    async function submitEnrollment() {
        isProcessing = true;
        enrollTypingInput.disabled = true;
        appendLog(`Training personalized Deep Neural Network for ${enrollUsername.value}...`, "info");

        try {
            const res = await fetch('/enroll', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    username: enrollUsername.value.trim(),
                    password: enrollPassword.value.trim(),
                    attempts: enrollAttempts
                })
            });
            const data = await res.json();
            if (data.status === 'SUCCESS') {
                appendLog(`[DNN Trained] ${data.message}`, 'success');
                appendLog(`Your typing rhythm → Avg Dwell: ${data.metrics.avg_dwell.toFixed(1)}ms | Avg Flight: ${data.metrics.avg_flight.toFixed(1)}ms`, 'success');
                appendLog(`Model & profile saved to database. User is now enrollable for auth.`, 'success');
                // Reset form
                enrollUsername.disabled = false;
                enrollPassword.disabled = false;
                startEnrollBtn.classList.remove('hidden');
                enrollBox.classList.add('hidden');
                enrollUsername.value = '';
                enrollPassword.value = '';
                enrollKeyEvents = [];
                enrollAttempts = [];
                // Auto-refresh auth user list in background
                loadUsers();
            } else {
                appendLog(`Enrollment failed: ${data.message}`, 'error');
                // Reset so they don't get stuck
                enrollAttempts = [];
                enrollKeyEvents = [];
                enrollTypingInput.value = '';
                enrollInstruction.textContent = `Type your password (Attempt 1 of 5):`;
            }
        } catch (e) {
            appendLog(`Network error during enrollment.`, 'error');
        } finally {
            isProcessing = false;
            enrollTypingInput.disabled = false;
        }
    }


    // ==========================================
    // PHASE 2: AUTHENTICATION LOGIC
    // ==========================================
    async function loadUsers() {
        try {
            const res = await fetch('/users');
            const users = await res.json();
            authSelectUser.innerHTML = '<option value="">-- Select --</option>';
            usersMap = {};
            users.forEach(u => {
                usersMap[u.username] = u.password;
                const opt = document.createElement('option');
                opt.value = u.username;
                opt.textContent = u.username;
                authSelectUser.appendChild(opt);
            });
            if (users.length === 0) {
                authSelectUser.innerHTML = '<option value="">No users enrolled yet.</option>';
            }
        } catch (e) {
            appendLog("Failed to load users.", "error");
        }
    }

    authSelectUser.addEventListener('change', () => {
        const user = authSelectUser.value;
        if (user) {
            authExpectedPassword.textContent = usersMap[user];
            authTypingInput.disabled = false;
            clearAuthInput();
        } else {
            authExpectedPassword.textContent = "...";
            authTypingInput.disabled = true;
        }
    });

    clearAuthBtn.addEventListener('click', clearAuthInput);

    function clearAuthInput() {
        authTypingInput.value = '';
        authKeyEvents = [];
        authTypingStatus.textContent = 'Waiting for input...';
        if (authSelectUser.value) {
            authTypingInput.disabled = false;
            authTypingInput.focus();
        } else {
            authTypingInput.disabled = true;
        }
    }

    authTypingInput.addEventListener('keydown', (e) => captureKey(e, authKeyEvents));
    authTypingInput.addEventListener('keyup', (e) => {
        if (captureKey(e, authKeyEvents)) checkAuthCompletion();
    });

    function checkAuthCompletion() {
        const expected = usersMap[authSelectUser.value];
        if (!expected) return; // guard: no user selected
        setTimeout(() => {
            const val = authTypingInput.value;
            authTypingStatus.textContent = `Typed: ${val.length} / ${expected.length}`;
            if (val.length >= expected.length) {
                if (val === expected) {
                    submitAuthentication();
                } else {
                    appendLog(`Mismatch. Expected '${expected}'. Cleared.`, 'error');
                    clearAuthInput();
                }
            }
        }, 10);
    }

    async function submitAuthentication() {
        isProcessing = true;
        authTypingInput.disabled = true;
        authTypingStatus.textContent = 'Authenticating...';
        
        const username = authSelectUser.value;
        appendLog(`Authenticating against model for ${username}...`, 'info');

        try {
            const res = await fetch('/authenticate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    username: username,
                    events: authKeyEvents
                })
            });
            const data = await res.json();
            if (data.status === 'SUCCESS') {
                const type = data.verdict === 'ACCEPTED' ? 'success' : 'error';
                appendLog(`Result: [${data.verdict}] - ${data.message}`, type);
            } else {
                appendLog(`Error: ${data.message}`, 'error');
            }
        } catch (e) {
            appendLog(`Network error.`, 'error');
        } finally {
            isProcessing = false;
            setTimeout(clearAuthInput, 2000);
        }
    }

    // Init
    loadUsers();
});
