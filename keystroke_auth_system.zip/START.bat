@echo off
REM ============================================================
REM  Keystroke Dynamics Auth — One-Click Setup and Launch
REM  Works on any Windows machine with Python 3.10-3.13.
REM ============================================================
title Keystroke Dynamics — Setup
color 0A

echo.
echo  ========================================================
echo    Keystroke Dynamics Authentication System
echo    One-Click Setup and Launch Script
echo  ========================================================
echo.

REM --- Step 0: Ensure we are in the correct directory ---
cd /d "%~dp0"
if not exist "requirements.txt" (
    echo [ERROR] Could not find requirements.txt!
    echo.
    echo         IMPORTANT: You must EXTRACT the .zip file first.
    echo         Do not run this directly inside the zip folder.
    echo         Right-click the zip file then Extract All
    echo         then run START.bat from the new extracted folder.
    echo.
    pause
    exit /b 1
)

REM --- Step 1: Check Python ---
echo [1/5] Checking for Python installation...
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH.
    echo         Please install Python 3.10-3.13 from https://www.python.org/downloads/
    echo         Make sure to check "Add Python to PATH" during installation.
    pause
    exit /b 1
)

REM --- Check Python version compatibility ---
for /f "tokens=2 delims= " %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo         Found Python %PYVER%

REM Extract major.minor version
for /f "tokens=1,2 delims=." %%a in ("%PYVER%") do (
    set PYMAJOR=%%a
    set PYMINOR=%%b
)

REM TensorFlow requires Python 3.10-3.13
if %PYMINOR% GEQ 14 (
    echo.
    echo [WARNING] Python %PYVER% detected. TensorFlow does NOT support Python 3.14+ yet.
    echo           Please install Python 3.12 or 3.13 from https://www.python.org/downloads/
    echo           You can have multiple Python versions installed side by side.
    echo.
    pause
    exit /b 1
)
if %PYMINOR% LSS 10 (
    echo.
    echo [WARNING] Python %PYVER% is too old. TensorFlow requires Python 3.10 or higher.
    echo           Please install Python 3.12 or 3.13 from https://www.python.org/downloads/
    echo.
    pause
    exit /b 1
)
echo.

REM --- Step 2: Create Virtual Environment ---
echo [2/5] Creating virtual environment...
if exist "venv\Scripts\activate.bat" (
    echo         Virtual environment already exists. Skipping creation.
) else (
    python -m venv venv
    if errorlevel 1 (
        echo [ERROR] Failed to create virtual environment.
        pause
        exit /b 1
    )
    echo         Virtual environment created successfully.
)
echo.

REM --- Step 3: Install Dependencies ---
echo [3/5] Installing dependencies (this may take 2-5 minutes on first run)...
call venv\Scripts\activate.bat

pip install --upgrade pip >nul 2>&1
pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo [ERROR] Failed to install one or more dependencies.
    echo         Check your internet connection and try again.
    pause
    exit /b 1
)
echo.
echo         All dependencies installed successfully.
echo.

REM --- Step 4: Create output directories ---
echo [4/5] Setting up project directories...
if not exist "outputs\saved_models" mkdir "outputs\saved_models"
if not exist "outputs\user_profiles" mkdir "outputs\user_profiles"
if not exist "outputs\plots" mkdir "outputs\plots"
echo         Done.
echo.

REM --- Step 5: Launch ---
echo [5/5] Launching Keystroke Dynamics Web Application...
echo.
echo  ========================================================
echo.
echo    Open your browser and go to:
echo    http://localhost:5000
echo.
echo    Press Ctrl+C in this window to stop the server.
echo.
echo  ========================================================
echo.

python app.py

pause
