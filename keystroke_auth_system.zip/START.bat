@echo off
REM ============================================================
REM  Keystroke Dynamics Auth — One-Click Setup and Launch
REM  Works on any Windows machine with Python 3.10+ installed.
REM ============================================================
title Keystroke Dynamics — Setup
color 0A

echo.
echo  ╔══════════════════════════════════════════════════╗
echo  ║   Keystroke Dynamics Authentication System       ║
echo  ║   One-Click Setup and Launch Script              ║
echo  ╚══════════════════════════════════════════════════╝
echo.

REM --- Step 1: Check Python ---
echo [1/4] Checking for Python installation...
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH.
    echo         Please install Python 3.10+ from https://www.python.org/downloads/
    echo         Make sure to check "Add Python to PATH" during installation.
    pause
    exit /b 1
)
for /f "tokens=2 delims= " %%v in ('python --version 2^>^&1') do (
    echo         Found Python %%v
)
echo.

REM --- Step 2: Create Virtual Environment ---
echo [2/4] Creating virtual environment...
if exist "venv\Scripts\activate.bat" (
    echo         Virtual environment already exists. Skipping creation.
) else (
    python -m venv venv
    if errorlevel 1 (
        echo [ERROR] Failed to create virtual environment.
        pause
        exit /b 1
    )
    echo         Virtual environment created successfully.
)
echo.

REM --- Step 3: Install Dependencies ---
echo [3/4] Installing dependencies (this may take 2-5 minutes on first run)...
call venv\Scripts\activate.bat

pip install --upgrade pip >nul 2>&1
pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Failed to install one or more dependencies.
    echo         Check your internet connection and try again.
    pause
    exit /b 1
)
echo.
echo         All dependencies installed successfully.
echo.

REM --- Step 4: Create output directories ---
if not exist "outputs\saved_models" mkdir "outputs\saved_models"
if not exist "outputs\user_profiles" mkdir "outputs\user_profiles"
if not exist "outputs\plots" mkdir "outputs\plots"

REM --- Step 5: Launch ---
echo [4/4] Launching Keystroke Dynamics Web Application...
echo.
echo  ╔══════════════════════════════════════════════════╗
echo  ║                                                  ║
echo  ║   Open your browser and go to:                   ║
echo  ║   http://localhost:5000                           ║
echo  ║                                                  ║
echo  ║   Press Ctrl+C in this window to stop the server ║
echo  ║                                                  ║
echo  ╚══════════════════════════════════════════════════╝
echo.

python app.py

pause
