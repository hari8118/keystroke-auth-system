import os
import json
import numpy as np
import tensorflow as tf
from sklearn.model_selection import train_test_split
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping
from src.config import MODELS_DIR, PROFILES_DIR, BATCH_SIZE, EPOCHS, LEARNING_RATE, TEST_SPLIT, RANDOM_SEED, get_total_features
from src.model import build_model
from src.evaluator import calculate_eer
import logging

log_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'backend.log')
logging.basicConfig(
    filename=log_path,
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def train_live_user(username, password_str, press_times_array, release_times_array):
    """
    Trains a model dynamically for a newly enrolled user from 5 raw samples.
    """
    password_len = len(password_str)
    num_digraphs = password_len - 1
    input_dim = get_total_features(password_len)
    
    # 1. Calculate Mean and Std from the 5 live samples
    N = press_times_array.shape[0]
    # Dwell Time
    dwell_times = release_times_array - press_times_array
    dwell_mean = np.mean(dwell_times, axis=0)
    dwell_std = np.std(dwell_times, axis=0)
    dwell_std = np.where(dwell_std < 5, 5, dwell_std) # Provide minimum variance
    
    # Flight Time
    flight_times = np.zeros((N, num_digraphs))
    for i in range(num_digraphs):
        flight_times[:, i] = press_times_array[:, i+1] - release_times_array[:, i]
    flight_mean = np.mean(flight_times, axis=0)
    flight_std = np.std(flight_times, axis=0)
    flight_std = np.where(flight_std < 10, 10, flight_std)
    
    # 2. Generate 500 synthetic genuine samples based on this live mean/std
    # Actually it's easier to just generate features directly rather than raw times.
    num_genuine = 500
    genuine_features = np.zeros((num_genuine, input_dim))
    
    gen_dwell = np.random.normal(loc=dwell_mean, scale=dwell_std, size=(num_genuine, password_len))
    gen_dwell = np.clip(gen_dwell, 10, None) # clip to minimum 10ms
    
    gen_flight = np.random.normal(loc=flight_mean, scale=flight_std, size=(num_genuine, num_digraphs))
    
    for i in range(num_digraphs):
        base_idx = i * 3
        genuine_features[:, base_idx] = gen_dwell[:, i]
        genuine_features[:, base_idx+1] = gen_flight[:, i]
        # Latency is flight + dwell of previous key
        genuine_features[:, base_idx+2] = gen_flight[:, i] + gen_dwell[:, i]
        
    # 3. Generate 500 impostor samples using broad typical human distributions
    num_impostor = 500
    impostor_features = np.zeros((num_impostor, input_dim))
    
    imp_dwell_mean = np.random.uniform(80, 150, size=password_len)
    imp_dwell_std = np.random.uniform(10, 30, size=password_len)
    imp_flight_mean = np.random.uniform(100, 250, size=num_digraphs)
    imp_flight_std = np.random.uniform(20, 50, size=num_digraphs)
    
    imp_dwell = np.random.normal(loc=imp_dwell_mean, scale=imp_dwell_std, size=(num_impostor, password_len))
    imp_flight = np.random.normal(loc=imp_flight_mean, scale=imp_flight_std, size=(num_impostor, num_digraphs))
    
    for i in range(num_digraphs):
        base_idx = i * 3
        impostor_features[:, base_idx] = imp_dwell[:, i]
        impostor_features[:, base_idx+1] = imp_flight[:, i]
        impostor_features[:, base_idx+2] = imp_flight[:, i] + imp_dwell[:, i]
        
    # 4. Normalize
    X = np.vstack([genuine_features, impostor_features])
    y = np.array([1]*num_genuine + [0]*num_impostor)
    
    # Shuffle
    idx = np.arange(len(y))
    np.random.shuffle(idx)
    X = X[idx]
    y = y[idx]
    
    # Calculate global mean/std for this user (custom password so they get their own normalization)
    feat_mean = np.mean(X, axis=0)
    feat_std = np.std(X, axis=0)
    feat_std = np.where(feat_std == 0, 1e-6, feat_std)
    
    X_norm = (X - feat_mean) / feat_std
    X_norm = np.clip(X_norm, -3, 3)
    X_norm = (X_norm + 3.0) / 6.0
    
    # 5. Train Model
    X_train, X_val, y_train, y_val = train_test_split(X_norm, y, test_size=TEST_SPLIT, random_state=RANDOM_SEED)
    
    model = build_model(input_dim)
    model.compile(optimizer=Adam(learning_rate=LEARNING_RATE), loss='binary_crossentropy', metrics=['accuracy'])
    
    early_stop = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
    
    
    logger.info(f"Training DNN for {username} on {password_str}...")
    model.fit(X_train, y_train, validation_data=(X_val, y_val), epochs=EPOCHS, batch_size=BATCH_SIZE, callbacks=[early_stop], verbose=0)
    
    # 6. Evaluate EER to find threshold
    y_scores = model.predict(X_val, verbose=0).flatten()
    eer, opt_thresh, _, _ = calculate_eer(y_val, y_scores)
    logger.info(f"[{username}] Trained successfully. Val EER: {eer:.4f}, Thresh: {opt_thresh:.4f}")
    
    # 7. Save model and stats
    model_path = os.path.join(MODELS_DIR, f"live_{username}.keras")
    model.save(model_path)
    
    profile_data = {
        "username": username,
        "password": password_str,
        "password_len": password_len,
        "threshold": float(opt_thresh),
        "norm_mean": feat_mean.tolist(),
        "norm_std": feat_std.tolist()
    }
    
    with open(os.path.join(PROFILES_DIR, f"live_{username}.json"), "w") as f:
        json.dump(profile_data, f)
        
    return profile_data
