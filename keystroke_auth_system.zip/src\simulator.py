import os
import json
import numpy as np
import tensorflow as tf
from src.config import NUM_USERS, MODELS_DIR, PROFILES_DIR
from src.data_generator import generate_samples_for_user
from src.feature_extractor import extract_features

def simulate_logins(num_attempts=20):
    """
    Simulates live login attempts.
    """
    print(f"\nRunning {num_attempts} simulated login attempts...")
    
    # Load global normalization params
    norm_path = os.path.join(PROFILES_DIR, "global_norm.json")
    if not os.path.exists(norm_path):
        print("Normalization parameters not found. Train models first.")
        return
        
    with open(norm_path, "r") as f:
        norm_params = json.load(f)
    mean = np.array(norm_params["mean"])
    std = np.array(norm_params["std"])
    
    # Load evaluation results to get optimal thresholds
    eval_path = os.path.join(PROFILES_DIR, "evaluation_results.json")
    if not os.path.exists(eval_path):
        print("Evaluation results not found. Run evaluation first.")
        return
        
    with open(eval_path, "r") as f:
        eval_results = json.load(f)["per_user"]
        
    # Pre-load all models to avoid loading them repeatedly
    models = {}
    for user_id in range(NUM_USERS):
        model_path = os.path.join(MODELS_DIR, f"user_{user_id}.keras")
        if os.path.exists(model_path):
            models[user_id] = tf.keras.models.load_model(model_path)
    
    correct_verdicts = 0
    
    for i in range(num_attempts):
        # 1. Randomly select a claimed user
        claimed_user = np.random.randint(0, NUM_USERS)
        
        # 2. Decide if this is a genuine attempt or an impostor (50/50)
        is_genuine = np.random.choice([True, False])
        
        if is_genuine:
            actual_user = claimed_user
        else:
            # Pick a random other user as the impostor
            possible_impostors = [u for u in range(NUM_USERS) if u != claimed_user]
            actual_user = np.random.choice(possible_impostors)
            
        # 3. Generate a sample from the actual user's profile
        profile_path = os.path.join(PROFILES_DIR, f"user_{actual_user}.json")
        with open(profile_path, "r") as f:
            profile = json.load(f)
            
        # Convert lists back to numpy arrays
        profile = {k: np.array(v) for k, v in profile.items()}
        
        press, release = generate_samples_for_user(profile, num_samples=1)
        raw_feature = extract_features(press, release)
        
        # Normalize using global stats
        norm_feature = (raw_feature - mean) / std
        norm_feature = np.clip(norm_feature, -3, 3)
        norm_feature = (norm_feature + 3.0) / 6.0
        
        # 4. Predict using the claimed user's model
        model = models.get(claimed_user)
        if model is None:
            print(f"Attempt {i+1}: Model for claimed user {claimed_user} missing.")
            continue
            
        score = model.predict(norm_feature, verbose=0)[0][0]
        threshold = eval_results[str(claimed_user)]["optimal_threshold"]
        
        is_accepted = score >= threshold
        
        # 5. Evaluate verdict
        expected_accept = is_genuine
        correct = (is_accepted == expected_accept)
        if correct:
            correct_verdicts += 1
            
        status = "[ACCEPTED]" if is_accepted else "[REJECTED]"
        truth = "Genuine" if is_genuine else f"Impostor (User {actual_user})"
        
        print(f"  Attempt {i+1:02d} | Claimed: User {claimed_user} | Actual: {truth:20s} | Score: {score:.4f} (Thresh: {threshold:.4f}) | {status} {'(Correct)' if correct else '(Incorrect)'}")
        
    print(f"\nSimulation Accuracy: {correct_verdicts}/{num_attempts} ({(correct_verdicts/num_attempts)*100:.1f}%)")

if __name__ == "__main__":
    simulate_logins()
