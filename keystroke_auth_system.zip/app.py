import os
import glob
import json
import numpy as np
import logging
from flask import Flask, render_template, request, jsonify
import tensorflow as tf

from src.config import MODELS_DIR, PROFILES_DIR
from src.feature_extractor import extract_features
from src.live_trainer import train_live_user

# Configure logging to write to a file
log_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'backend.log')
logging.basicConfig(
    filename=log_path,
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

app = Flask(__name__)
# Also route Flask's internal logs to our logger
app.logger.handlers = logging.getLogger().handlers

# Keep models in memory
live_models = {}
live_profiles = {}

def load_live_data():
    global live_models, live_profiles
    live_models.clear()
    live_profiles.clear()
    
    profile_files = glob.glob(os.path.join(PROFILES_DIR, "live_*.json"))
    for pf in profile_files:
        with open(pf, "r") as f:
            profile = json.load(f)
            username = profile['username']
            live_profiles[username] = profile
            
        model_path = os.path.join(MODELS_DIR, f"live_{username}.keras")
        if os.path.exists(model_path):
            live_models[username] = tf.keras.models.load_model(model_path)
            
            
    app.logger.info(f"Loaded {len(live_models)} live users.")

load_live_data()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/users', methods=['GET'])
def get_users():
    users = []
    for username, profile in live_profiles.items():
        users.append({
            "username": username,
            "password": profile["password"]
        })
    return jsonify(users)

def parse_events(events, expected_phrase):
    """
    Parses key events and extracts press/release times for each character in order.
    
    Uses `code` (physical key, e.g. "KeyH") to pair keydown→keyup, which is
    stable regardless of whether Shift is held at the moment of release.
    Uses `key` (logical character, e.g. "H") to match against the expected password.
    """
    press_times_list = []
    release_times_list = []
    
    expected_list = list(expected_phrase)
    current_char_idx = 0
    pending_press_time = None
    pending_code = None  # physical key code of the pending keydown
    
    for ev in events:
        key = ev.get('key', '')
        code = ev.get('code', '')
        event_type = ev['type']
        time = ev['time']
        
        if current_char_idx >= len(expected_list):
            break
            
        expected_char = expected_list[current_char_idx]
        
        if event_type == 'keydown' and key == expected_char and pending_press_time is None:
            # Character matches — record the press and remember the physical key
            pending_press_time = time
            pending_code = code
        elif event_type == 'keyup' and pending_press_time is not None:
            # Match keyup by physical key code (not by character),
            # so "H" keydown + "h" keyup (Shift released early) still pairs correctly
            if code == pending_code:
                press_times_list.append(pending_press_time)
                release_times_list.append(time)
                pending_press_time = None
                pending_code = None
                current_char_idx += 1
                
    if len(press_times_list) != len(expected_phrase) or len(release_times_list) != len(expected_phrase):
        return None, None
        
    start_time = press_times_list[0]
    press_times = np.array(press_times_list) - start_time
    release_times = np.array(release_times_list) - start_time
    return press_times, release_times

@app.route('/enroll', methods=['POST'])
def enroll():
    data = request.json
    username = data.get('username')
    password_str = data.get('password')
    attempts = data.get('attempts', [])
    
    if len(password_str) < 4:
        return jsonify({"status": "ERROR", "message": "Password must be at least 4 characters."})
        
    if len(attempts) != 5:
        return jsonify({"status": "ERROR", "message": "Exactly 5 typing attempts required."})
        
    all_press = []
    all_release = []
    
    for attempt_events in attempts:
        p, r = parse_events(attempt_events, password_str)
        if p is None or r is None:
            return jsonify({"status": "ERROR", "message": "One of the attempts was typed incorrectly."})
        all_press.append(p)
        all_release.append(r)
        
    all_press = np.vstack(all_press)
    all_release = np.vstack(all_release)
    
    # Train
    try:
        profile = train_live_user(username, password_str, all_press, all_release)
        # Reload models
        load_live_data()
        
        # Calculate avg dwell and flight for UI display
        dwells = np.mean(all_release - all_press)
        flights = []
        for i in range(len(password_str)-1):
            flights.extend(all_press[:, i+1] - all_release[:, i])
        avg_flight = np.mean(flights) if flights else 0
        
        return jsonify({
            "status": "SUCCESS", 
            "message": f"User {username} enrolled.",
            "metrics": {
                "avg_dwell": float(dwells),
                "avg_flight": float(avg_flight)
            }
        })
    except Exception as e:
        app.logger.error(f"Enrollment Error: {str(e)}")
        return jsonify({"status": "ERROR", "message": str(e)})


@app.route('/authenticate', methods=['POST'])
def authenticate():
    data = request.json
    username = data.get('username')
    events = data.get('events', [])
    
    if username not in live_profiles:
        return jsonify({"status": "ERROR", "message": "User not found."})
        
    profile = live_profiles[username]
    expected_phrase = profile["password"]
    
    p, r = parse_events(events, expected_phrase)
    if p is None or r is None:
        return jsonify({
            "status": "ERROR",
            "message": f"Incomplete or incorrect phrase. Expected '{expected_phrase}'."
        })
        
    # Reshape for extractor
    p = p.reshape(1, -1)
    r = r.reshape(1, -1)
    
    # Extract features
    raw_feature = extract_features(p, r)
    
    # Normalize features
    norm_mean = np.array(profile["norm_mean"])
    norm_std = np.array(profile["norm_std"])
    
    norm_feature = (raw_feature - norm_mean) / norm_std
    norm_feature = np.clip(norm_feature, -3, 3)
    norm_feature = (norm_feature + 3.0) / 6.0
    
    # Predict
    model = live_models.get(username)
    if model is None:
        return jsonify({"status": "ERROR", "message": "Model not found."})
        
    score = float(model.predict(norm_feature, verbose=0)[0][0])
    threshold = profile["threshold"]
    
    is_accepted = score >= threshold
    
    app.logger.info(f"Auth attempt for {username} - Score: {score:.4f} | Thresh: {threshold:.4f} | Verdict: {'ACCEPTED' if is_accepted else 'REJECTED'}")
    
    return jsonify({
        "status": "SUCCESS",
        "verdict": "ACCEPTED" if is_accepted else "REJECTED",
        "score": score,
        "threshold": threshold,
        "message": f"Score: {score:.4f} | Thresh: {threshold:.4f}"
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000, use_reloader=False)
