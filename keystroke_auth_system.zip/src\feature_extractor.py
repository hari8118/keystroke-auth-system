import numpy as np

def extract_features(press_times, release_times):
    """
    Extracts dwell time, flight time, and digraph latency from raw press/release times.
    
    press_times: array of shape (N, NUM_CHARS)
    release_times: array of shape (N, NUM_CHARS)
    
    Returns: array of shape (N, TOTAL_FEATURES)
    """
    N = press_times.shape[0]
    num_chars = press_times.shape[1]
    num_digraphs = num_chars - 1
    total_features = num_digraphs * 3
    features = np.zeros((N, total_features))
    
    # Dwell Time: Release(N) - Press(N)
    dwell_times = release_times - press_times
    
    # We only use dwell times of the first NUM_DIGRAPHS keys to match feature counts
    # (or we could use all chars, but plan says 9 digraphs * 3 features)
    
    # Flight Time: Press(N+1) - Release(N)
    flight_times = np.zeros((N, num_digraphs))
    
    # Digraph Latency: Press(N+1) - Press(N)
    digraph_latency = np.zeros((N, num_digraphs))
    
    for i in range(num_digraphs):
        flight_times[:, i] = press_times[:, i+1] - release_times[:, i]
        digraph_latency[:, i] = press_times[:, i+1] - press_times[:, i]
        
        # Feature packing per digraph
        # Index layout: [Dwell1, Flight1, Latency1, Dwell2, Flight2, Latency2, ...]
        base_idx = i * 3
        features[:, base_idx] = dwell_times[:, i]
        features[:, base_idx+1] = flight_times[:, i]
        features[:, base_idx+2] = digraph_latency[:, i]
        
    return features

def normalize_features(features):
    """
    Z-score normalization and clipping
    """
    # Clip outliers
    mean = np.mean(features, axis=0)
    std = np.std(features, axis=0)
    std = np.where(std == 0, 1e-6, std) # Avoid div by zero
    
    norm_features = (features - mean) / std
    
    # Clip to +/- 3 sigma
    norm_features = np.clip(norm_features, -3, 3)
    
    # Scale roughly to [0, 1] using min-max on clipped data
    # Actual range is [-3, 3] -> [0, 1]
    scaled = (norm_features + 3.0) / 6.0
    return scaled, mean, std

if __name__ == "__main__":
    # Test extraction
    from src.data_generator import create_dataset
    p, r, y = create_dataset()
    f = extract_features(p, r)
    f_norm, _, _ = normalize_features(f)
    print(f"Extracted features shape: {f.shape}")
    print(f"Normalized features min: {np.min(f_norm):.2f}, max: {np.max(f_norm):.2f}")
