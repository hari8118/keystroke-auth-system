import os
import numpy as np
import json
import tensorflow as tf
from sklearn.model_selection import train_test_split
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
from src.config import (NUM_USERS, MODELS_DIR, PROFILES_DIR, 
                        BATCH_SIZE, EPOCHS, LEARNING_RATE, TEST_SPLIT, RANDOM_SEED, PHRASE, get_total_features)
from src.model import build_model
from src.data_generator import create_dataset
from src.feature_extractor import extract_features, normalize_features

def train_user_models():
    """
    Trains one-vs-rest classifiers for all users.
    Saves models and normalization params.
    """
    print("Generating synthetic keystroke data...")
    press, release, labels = create_dataset()
    
    print("Extracting features...")
    raw_features = extract_features(press, release)
    features, mean, std = normalize_features(raw_features)
    
    # Save global normalization params to be used in inference
    norm_params = {"mean": mean.tolist(), "std": std.tolist()}
    with open(os.path.join(PROFILES_DIR, "global_norm.json"), "w") as f:
        json.dump(norm_params, f)
        
    histories = {}
    
    for target_user in range(NUM_USERS):
        print(f"Training model for User {target_user}...")
        
        # Binary labels: 1 for target_user, 0 for impostors
        y_binary = (labels == target_user).astype(int)
        
        # Undersampling impostors to balance classes
        genuine_idx = np.where(y_binary == 1)[0]
        impostor_idx = np.where(y_binary == 0)[0]
        
        # Subsample impostors to match genuine count for balanced training
        np.random.shuffle(impostor_idx)
        selected_impostor_idx = impostor_idx[:len(genuine_idx)]
        
        balanced_idx = np.concatenate([genuine_idx, selected_impostor_idx])
        np.random.shuffle(balanced_idx)
        
        X_bal = features[balanced_idx]
        y_bal = y_binary[balanced_idx]
        
        X_train, X_val, y_train, y_val = train_test_split(
            X_bal, y_bal, test_size=TEST_SPLIT, random_state=RANDOM_SEED, stratify=y_bal
        )
        
        model = build_model(get_total_features(len(PHRASE)))
        model.compile(
            optimizer=Adam(learning_rate=LEARNING_RATE),
            loss='binary_crossentropy',
            metrics=['accuracy']
        )
        
        model_path = os.path.join(MODELS_DIR, f"user_{target_user}.keras")
        callbacks = [
            EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True),
            ModelCheckpoint(filepath=model_path, monitor='val_loss', save_best_only=True)
        ]
        
        history = model.fit(
            X_train, y_train,
            validation_data=(X_val, y_val),
            epochs=EPOCHS,
            batch_size=BATCH_SIZE,
            callbacks=callbacks,
            verbose=0  # Silent training
        )
        
        # Evaluate on validation set
        val_loss, val_acc = model.evaluate(X_val, y_val, verbose=0)
        print(f"  [OK] User {target_user} Model - Val Acc: {val_acc:.4f}, Val Loss: {val_loss:.4f}")
        histories[target_user] = history.history
        
    # Save training histories for plotting
    with open(os.path.join(PROFILES_DIR, "training_history.json"), "w") as f:
        json.dump(histories, f)
        
    return features, labels, histories

if __name__ == "__main__":
    train_user_models()
