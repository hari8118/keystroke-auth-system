import os
import numpy as np
import tensorflow as tf
from sklearn.metrics import roc_curve, auc, confusion_matrix
import json
from src.config import NUM_USERS, MODELS_DIR, PROFILES_DIR, PLOTS_DIR

def calculate_eer(y_true, y_scores):
    """
    Calculates the Equal Error Rate (EER) and the optimal threshold.
    """
    fpr, tpr, thresholds = roc_curve(y_true, y_scores)
    fnr = 1 - tpr
    
    # EER is where FAR (fpr) == FRR (fnr)
    # Find the threshold that minimizes the difference between FAR and FRR
    absolute_difference = np.abs(fpr - fnr)
    min_idx = np.argmin(absolute_difference)
    
    eer = (fpr[min_idx] + fnr[min_idx]) / 2.0
    optimal_threshold = thresholds[min_idx]
    
    return eer, optimal_threshold, fpr, tpr

def evaluate_system(features, labels):
    """
    Evaluates all trained user models on the entire dataset.
    Computes per-user FAR, FRR, EER and aggregate metrics.
    """
    print("\nEvaluating system performance...")
    
    results = {}
    aggregate_y_true = []
    aggregate_y_pred = []
    
    # Store ROC curve data for plotting later
    roc_data = {}
    
    for user_id in range(NUM_USERS):
        model_path = os.path.join(MODELS_DIR, f"user_{user_id}.keras")
        if not os.path.exists(model_path):
            print(f"Model for User {user_id} not found. Skipping evaluation.")
            continue
            
        model = tf.keras.models.load_model(model_path)
        
        # Binary labels
        y_true = (labels == user_id).astype(int)
        
        # Get prediction scores
        y_scores = model.predict(features, verbose=0).flatten()
        
        # Calculate EER and optimal threshold
        eer, opt_thresh, fpr, tpr = calculate_eer(y_true, y_scores)
        
        # Calculate FAR and FRR at optimal threshold
        y_pred = (y_scores >= opt_thresh).astype(int)
        
        tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
        far = fp / (fp + tn) if (fp + tn) > 0 else 0
        frr = fn / (fn + tp) if (fn + tp) > 0 else 0
        
        results[user_id] = {
            "eer": float(eer),
            "optimal_threshold": float(opt_thresh),
            "far": float(far),
            "frr": float(frr)
        }
        
        roc_data[user_id] = {
            "fpr": fpr.tolist(),
            "tpr": tpr.tolist(),
            "auc": float(auc(fpr, tpr))
        }
        
        print(f"  [OK] User {user_id} - EER: {eer:.4f}, FAR: {far:.4f}, FRR: {frr:.4f}")
        
        aggregate_y_true.extend(y_true)
        aggregate_y_pred.extend(y_pred)

    # Calculate aggregate metrics
    tn, fp, fn, tp = confusion_matrix(aggregate_y_true, aggregate_y_pred).ravel()
    agg_far = fp / (fp + tn)
    agg_frr = fn / (fn + tp)
    
    print(f"\nSystem Aggregate - FAR: {agg_far:.4f}, FRR: {agg_frr:.4f}")
    
    # Save results
    with open(os.path.join(PROFILES_DIR, "evaluation_results.json"), "w") as f:
        json.dump({
            "per_user": results,
            "aggregate": {"far": agg_far, "frr": agg_frr}
        }, f, indent=4)
        
    with open(os.path.join(PROFILES_DIR, "roc_data.json"), "w") as f:
        json.dump(roc_data, f)
        
    return results

if __name__ == "__main__":
    from src.data_generator import create_dataset
    from src.feature_extractor import extract_features, normalize_features
    p, r, y = create_dataset()
    f_raw = extract_features(p, r)
    f, _, _ = normalize_features(f_raw)
    evaluate_system(f, y)
