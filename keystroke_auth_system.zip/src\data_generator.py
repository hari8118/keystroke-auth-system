import numpy as np
import json
import os
from src.config import NUM_USERS, SAMPLES_PER_USER, NUM_DIGRAPHS, PROFILES_DIR, RANDOM_SEED

np.random.seed(RANDOM_SEED)

def generate_user_profile():
    """
    Generates a realistic typing profile for a single user.
    Returns means and std devs for dwell and flight times.
    """
    # Dwell time meta-distribution across population
    # Humans typically hold keys for 80-150ms
    dwell_mean = np.random.uniform(80, 150, size=NUM_DIGRAPHS+1) # +1 for last key release
    dwell_std = np.random.uniform(10, 30, size=NUM_DIGRAPHS+1)
    
    # Flight time meta-distribution across population
    # Gap between release and next press typically 100-250ms
    flight_mean = np.random.uniform(100, 250, size=NUM_DIGRAPHS)
    flight_std = np.random.uniform(20, 50, size=NUM_DIGRAPHS)
    
    return {
        "dwell_mean": dwell_mean,
        "dwell_std": dwell_std,
        "flight_mean": flight_mean,
        "flight_std": flight_std
    }

def generate_samples_for_user(profile, num_samples):
    """
    Given a user profile, generates 'num_samples' of raw timing events.
    Returns: press_times, release_times (shape: num_samples x chars)
    """
    dwell_times = np.random.normal(
        loc=profile['dwell_mean'], 
        scale=profile['dwell_std'], 
        size=(num_samples, NUM_DIGRAPHS+1)
    )
    # Ensure positive times
    dwell_times = np.clip(dwell_times, a_min=10, a_max=None)
    
    flight_times = np.random.normal(
        loc=profile['flight_mean'], 
        scale=profile['flight_std'], 
        size=(num_samples, NUM_DIGRAPHS)
    )
    
    press_times = np.zeros((num_samples, NUM_DIGRAPHS+1))
    release_times = np.zeros((num_samples, NUM_DIGRAPHS+1))
    
    # Start typing at t=0 for first key
    press_times[:, 0] = 0
    release_times[:, 0] = press_times[:, 0] + dwell_times[:, 0]
    
    for i in range(1, NUM_DIGRAPHS+1):
        press_times[:, i] = release_times[:, i-1] + flight_times[:, i-1]
        release_times[:, i] = press_times[:, i] + dwell_times[:, i]
        
    return press_times, release_times

def create_dataset():
    """
    Creates profiles and datasets for all users.
    Saves profiles to disk for reference.
    Returns X (features), Y (labels/user_ids)
    """
    profiles = []
    all_press_times = []
    all_release_times = []
    labels = []
    
    for user_id in range(NUM_USERS):
        profile = generate_user_profile()
        profiles.append(profile)
        
        # Save profile to JSON
        profile_serializable = {k: v.tolist() for k, v in profile.items()}
        with open(os.path.join(PROFILES_DIR, f"user_{user_id}.json"), "w") as f:
            json.dump(profile_serializable, f, indent=4)
            
        press, release = generate_samples_for_user(profile, SAMPLES_PER_USER)
        all_press_times.append(press)
        all_release_times.append(release)
        labels.extend([user_id] * SAMPLES_PER_USER)
        
    X_press = np.vstack(all_press_times)
    X_release = np.vstack(all_release_times)
    Y = np.array(labels)
    
    return X_press, X_release, Y

if __name__ == "__main__":
    p, r, y = create_dataset()
    print(f"Generated data shape: Press {p.shape}, Release {r.shape}, Labels {y.shape}")
