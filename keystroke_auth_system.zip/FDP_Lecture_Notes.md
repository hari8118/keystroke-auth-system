# Keystroke Dynamics Authentication
**Technical Lecture Notes for Faculty Development Program (FDP)**

---

### 1. Core Concept: Behavioral Biometrics
*   **Definition:** Unlike physiological biometrics (fingerprints, retina), behavioral biometrics authenticate users based on *how* they interact with devices.
*   **The Premise:** Every individual possesses a unique neuro-muscular rhythm when typing. This is a subconscious pattern that is nearly impossible to mimic, even if the password is known.
*   **Advantages:** Zero-friction (invisible to the user), continuous authentication capability, and no extra hardware required (just a standard keyboard).

---

### 2. Feature Engineering & Data Extraction
The system captures raw timing events and engineers them into a standardized feature vector.

*   **Primary Metrics Extracted:**
    *   **Dwell Time (Hold Time):** The duration a key is held down. Calculated as `KeyUp_Time - KeyDown_Time`.
    *   **Flight Time (Interval Time):** The gap between releasing one key and pressing the next. Calculated as `Next_KeyDown_Time - Current_KeyUp_Time`.
*   **Data Augmentation (Synthetic Data Generation):**
    *   *The Problem:* Asking a user to type a password 500 times for neural network training is terrible UX. We only capture 5 samples.
    *   *The Solution:* We calculate the Mean ($\mu$) and Standard Deviation ($\sigma$) of the 5 samples. We then generate synthetic "genuine" and "impostor" data points using a **Gaussian Distribution** (`np.random.normal`). This gives us enough data to train a deep learning model.
*   **Normalization (Z-Score):**
    *   Features are normalized using $Z = \frac{(X - \mu)}{\sigma}$. This ensures the neural network converges faster and isn't skewed by long absolute times.

---

### 3. Model Architecture: Deep Neural Network (DNN)
Instead of traditional statistical models (like Euclidean Distance or Mahalanobis distance), this system uses a modern Deep Learning approach.

*   **Framework:** Built using **TensorFlow** and **Keras**.
*   **Network Topology:** A personalized, Sequential Multi-Layer Perceptron (MLP) built dynamically for each user.
    *   **Input Layer:** Dimension equals the number of extracted features $(2N - 1)$, where $N$ is the password length.
    *   **Hidden Layer 1:** Dense layer (32 neurons) with **ReLU** (Rectified Linear Unit) activation to capture non-linear typing patterns.
    *   **Regularization:** **Dropout layer (0.3)** to prevent overfitting on the small synthetic dataset.
    *   **Hidden Layer 2:** Dense layer (16 neurons), ReLU activation.
    *   **Output Layer:** Single neuron with a **Sigmoid** activation function to output a probability score between $0.0$ and $1.0$ ($1.0$ being a perfect match).
*   **Compilation:**
    *   *Loss Function:* **Binary Crossentropy** (standard for binary classification: Genuine vs. Impostor).
    *   *Optimizer:* **Adam** (Adaptive Moment Estimation) for efficient gradient descent.

---

### 4. Evaluation Metrics & Dynamic Thresholding
A static threshold (e.g., "accept if score > 0.8") is flawed because some users are consistent typers and others are erratic. The system calculates a personalized threshold.

*   **False Acceptance Rate (FAR):** The probability that the system incorrectly authorizes an impostor.
*   **False Rejection Rate (FRR):** The probability that the system incorrectly rejects the genuine user.
*   **Equal Error Rate (EER):** The exact threshold point where FAR equals FRR. 
    *   *Implementation:* The system evaluates the model on a validation set, plots the ROC curve data, and finds the intersection of FAR and FRR to define the personalized acceptance threshold for that specific user.

---

### 5. The Technology Stack
*   **Frontend Interface:** Vanilla JavaScript, HTML5, CSS3. Captures microsecond-precision timestamps using the `performance.now()` API. Maps physical keys via `e.code` to handle Shift/Caps bypasses.
*   **Backend Server:** **Flask** (Python). Acts as the bridge, receiving REST API calls, routing data to the machine learning scripts, and maintaining models in memory.
*   **Machine Learning Core:** **NumPy** (matrix operations, Gaussian generation), **scikit-learn** (ROC metric calculations), and **TensorFlow/Keras** (Neural Network definition, training, and inference).
