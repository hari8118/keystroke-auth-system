import os
import sys

# Ensure the 'src' module can be imported
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from src.trainer import train_user_models
from src.evaluator import evaluate_system
from src.simulator import simulate_logins
from src.report import generate_report_and_plots
from src.config import MODELS_DIR, PROFILES_DIR, PLOTS_DIR, NUM_USERS

def run_pipeline():
    print("==================================================")
    print("  Keystroke Dynamics Biometric Auth System")
    print("==================================================\n")
    
    print("Step 1-3/7: Generating data, extracting features, and training models...")
    features, labels, _ = train_user_models()
    
    print("\nStep 4/7: Evaluating FAR / FRR / EER...")
    evaluate_system(features, labels)
    
    print("\nStep 5/7: Running live login simulation...")
    simulate_logins(num_attempts=20)
    
    print("\nStep 6/7: Generating plots and report...")
    generate_report_and_plots()
    
    print("\nStep 7/7: Self-check verification...")
    # Verify outputs
    models_count = len([name for name in os.listdir(MODELS_DIR) if name.endswith('.keras')])
    profiles_count = len([name for name in os.listdir(PROFILES_DIR) if name.startswith('user_') and name.endswith('.json')])
    plots_count = len([name for name in os.listdir(PLOTS_DIR) if name.endswith('.png')])
    report_exists = os.path.exists(os.path.join(os.path.dirname(MODELS_DIR), "report.txt"))
    
    all_good = True
    if models_count != NUM_USERS:
        print(f"  [FAIL] Missing models: found {models_count}/{NUM_USERS}")
        all_good = False
    else:
        print(f"  [OK] All {NUM_USERS} models saved successfully.")
        
    if profiles_count != NUM_USERS:
        print(f"  [FAIL] Missing profiles: found {profiles_count}/{NUM_USERS}")
        all_good = False
    else:
        print(f"  [OK] All {NUM_USERS} user profiles saved successfully.")
        
    if plots_count == 0:
        print("  [FAIL] Missing PNG plots.")
        all_good = False
    else:
        print(f"  [OK] PNG plots generated successfully.")
        
    if not report_exists:
        print("  [FAIL] Missing report.txt.")
        all_good = False
    else:
        print(f"  [OK] Final text report generated successfully.")
        
    if all_good:
        print("\n===========================================")
        print("  Keystroke Dynamics Auth System - COMPLETE")
        print(f"  Models saved to: {MODELS_DIR}")
        print(f"  Report saved to: {os.path.join(os.path.dirname(MODELS_DIR), 'report.txt')}")
        print(f"  Plots saved to:  {PLOTS_DIR}")
        print("===========================================")
    else:
        print("\n[WARNING] Pipeline completed with warnings. Check the errors above.")

if __name__ == "__main__":
    run_pipeline()
