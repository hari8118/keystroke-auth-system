import os
import json
import matplotlib
# Must be set BEFORE importing pyplot to avoid display backend errors
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from src.config import NUM_USERS, PROFILES_DIR, PLOTS_DIR, OUTPUT_DIR

def generate_report_and_plots():
    """
    Generates PNG plots and a summary text report.
    """
    print("\nGenerating report and plots...")
    
    eval_path = os.path.join(PROFILES_DIR, "evaluation_results.json")
    roc_path = os.path.join(PROFILES_DIR, "roc_data.json")
    history_path = os.path.join(PROFILES_DIR, "training_history.json")
    
    if not os.path.exists(eval_path) or not os.path.exists(roc_path):
        print("Required data for reporting is missing.")
        return
        
    with open(eval_path, "r") as f:
        eval_results = json.load(f)
        
    with open(roc_path, "r") as f:
        roc_data = json.load(f)
        
    # --- PLOT 1: ROC Curves ---
    plt.figure(figsize=(10, 8))
    for user_id_str, data in roc_data.items():
        plt.plot(data["fpr"], data["tpr"], lw=2, label=f'User {user_id_str} (AUC = {data["auc"]:.2f})')
        
    plt.plot([0, 1], [0, 1], color='gray', lw=2, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate (FAR)')
    plt.ylabel('True Positive Rate (1 - FRR)')
    plt.title('Receiver Operating Characteristic (ROC) per User')
    plt.legend(loc="lower right")
    plt.grid(True, alpha=0.3)
    plt.savefig(os.path.join(PLOTS_DIR, "roc_curves.png"), dpi=300, bbox_inches='tight')
    plt.close()
    
    # --- PLOT 2: Training History ---
    if os.path.exists(history_path):
        with open(history_path, "r") as f:
            histories = json.load(f)
            
        plt.figure(figsize=(12, 5))
        
        # Plot Loss
        plt.subplot(1, 2, 1)
        for user_id_str, history in histories.items():
            if 'loss' in history:
                plt.plot(history['loss'], alpha=0.3)
        plt.title('Training Loss Across Users')
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.grid(True, alpha=0.3)
        
        # Plot Accuracy
        plt.subplot(1, 2, 2)
        for user_id_str, history in histories.items():
            if 'accuracy' in history:
                plt.plot(history['accuracy'], alpha=0.3)
        plt.title('Training Accuracy Across Users')
        plt.xlabel('Epoch')
        plt.ylabel('Accuracy')
        plt.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(os.path.join(PLOTS_DIR, "training_history.png"), dpi=300, bbox_inches='tight')
        plt.close()
        
    # --- Text Report ---
    report_path = os.path.join(OUTPUT_DIR, "report.txt")
    with open(report_path, "w") as f:
        f.write("="*50 + "\n")
        f.write("KEYSTROKE DYNAMICS AUTHENTICATION - FINAL REPORT\n")
        f.write("="*50 + "\n\n")
        
        agg = eval_results["aggregate"]
        f.write(f"SYSTEM AGGREGATE PERFORMANCE:\n")
        f.write(f"False Accept Rate (FAR): {agg['far']*100:.2f}%\n")
        f.write(f"False Reject Rate (FRR): {agg['frr']*100:.2f}%\n\n")
        
        f.write("PER-USER METRICS:\n")
        f.write("-" * 65 + "\n")
        f.write(f"{'User ID':<10} | {'EER (%)':<10} | {'FAR (%)':<10} | {'FRR (%)':<10} | {'Threshold':<10}\n")
        f.write("-" * 65 + "\n")
        
        for user_id_str, metrics in eval_results["per_user"].items():
            f.write(f"{user_id_str:<10} | {metrics['eer']*100:<10.2f} | {metrics['far']*100:<10.2f} | {metrics['frr']*100:<10.2f} | {metrics['optimal_threshold']:<10.4f}\n")
            
        f.write("\n" + "="*50 + "\n")
        
    print(f"  [OK] Report saved to: {report_path}")
    print(f"  [OK] Plots saved to:  {PLOTS_DIR}")

if __name__ == "__main__":
    generate_report_and_plots()
