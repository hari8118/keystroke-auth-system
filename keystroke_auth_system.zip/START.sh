#!/bin/bash
# ============================================================
#  Keystroke Dynamics Auth — One-Click Setup and Launch
#  Works on any Linux/macOS machine with Python 3.10+ installed.
# ============================================================

echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║   Keystroke Dynamics Authentication System       ║"
echo "║   One-Click Setup and Launch Script              ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""

# --- Step 1: Check Python ---
echo "[1/4] Checking for Python installation..."
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python3 is not installed."
    echo "        Install it via: sudo apt install python3 python3-venv python3-pip"
    exit 1
fi
PYVER=$(python3 --version 2>&1)
echo "        Found $PYVER"
echo ""

# --- Step 2: Create Virtual Environment ---
echo "[2/4] Creating virtual environment..."
if [ -d "venv" ]; then
    echo "        Virtual environment already exists. Skipping creation."
else
    python3 -m venv venv
    if [ $? -ne 0 ]; then
        echo "[ERROR] Failed to create virtual environment."
        echo "        Try: sudo apt install python3-venv"
        exit 1
    fi
    echo "        Virtual environment created successfully."
fi
echo ""

# --- Step 3: Install Dependencies ---
echo "[3/4] Installing dependencies (this may take 2-5 minutes on first run)..."
source venv/bin/activate

pip install --upgrade pip > /dev/null 2>&1
pip install -r requirements.txt
if [ $? -ne 0 ]; then
    echo "[ERROR] Failed to install one or more dependencies."
    echo "        Check your internet connection and try again."
    exit 1
fi
echo ""
echo "        All dependencies installed successfully."
echo ""

# --- Step 4: Create output directories ---
mkdir -p outputs/saved_models outputs/user_profiles outputs/plots

# --- Step 5: Launch ---
echo "[4/4] Launching Keystroke Dynamics Web Application..."
echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║                                                  ║"
echo "║   Open your browser and go to:                   ║"
echo "║   http://localhost:5000                           ║"
echo "║                                                  ║"
echo "║   Press Ctrl+C in this window to stop the server ║"
echo "║                                                  ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""

python3 app.py
