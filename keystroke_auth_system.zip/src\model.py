import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, BatchNormalization, Input
from src.config import HIDDEN_LAYERS, DROPOUT_RATE

def build_model(input_dim):
    """
    Builds the dense neural network for binary classification (one-vs-rest).
    """
    model = Sequential()
    model.add(Input(shape=(input_dim,)))
    
    for units in HIDDEN_LAYERS:
        model.add(Dense(units, activation='relu'))
        model.add(BatchNormalization())
        model.add(Dropout(DROPOUT_RATE))
        
    model.add(Dense(1, activation='sigmoid'))
    
    return model

if __name__ == "__main__":
    from src.config import get_total_features
    # Example for password length 10
    model = build_model(get_total_features(10))
    model.summary()
