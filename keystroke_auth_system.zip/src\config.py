import os
import numpy as np
import tensorflow as tf

# Project Roots
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")
MODELS_DIR = os.path.join(OUTPUT_DIR, "saved_models")
PROFILES_DIR = os.path.join(OUTPUT_DIR, "user_profiles")
PLOTS_DIR = os.path.join(OUTPUT_DIR, "plots")

# Ensure directories exist
for d in [MODELS_DIR, PROFILES_DIR, PLOTS_DIR]:
    os.makedirs(d, exist_ok=True)

# Dynamic configuration
FEATURES_PER_DIGRAPH = 3  # Dwell, Flight, Digraph Latency

def get_total_features(password_len):
    return (password_len - 1) * FEATURES_PER_DIGRAPH

# Defaults (kept for compatibility with old code if needed)
NUM_USERS = 10
SAMPLES_PER_USER = 500
PHRASE = ".tie5Roanl"

# Model Parameters
HIDDEN_LAYERS = [128, 64, 32]
DROPOUT_RATE = 0.3
EPOCHS = 50
BATCH_SIZE = 32
LEARNING_RATE = 0.001

# Training Parameters
TEST_SPLIT = 0.2
RANDOM_SEED = 42

# Ensure reproducibility
np.random.seed(RANDOM_SEED)
tf.random.set_seed(RANDOM_SEED)
